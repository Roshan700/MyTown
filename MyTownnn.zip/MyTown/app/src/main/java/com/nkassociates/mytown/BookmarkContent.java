package com.nkassociates.mytown;

/**
 * Created by Roshan on 5/8/2018.
 */

public class BookmarkContent {
}
